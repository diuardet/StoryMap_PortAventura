 
Color        Number range  Web color  iconPrefix
-------      ------------  ---------  -----------------

Default colors

green        1 to 300      #22880d    NumberIcong
red          1 to 300      #fd2d29    NumberIconr
blue         1 to 200      #177ff1    NumberIconb
purple       1 to 200      #9c46fd    NumberIconp
black        1 to 200      #000000    NumberIconK

Extended colors

magenta      1 to 200      #b454cb    NumberIconM
orange       1 to 200      #e88516    NumberIconO
salmon       1 to 200      #C96A04    NumberIconS
tangerine    1 to 100      #FB921A    NumberIconT







